// import './graph'
import Vue from 'vue'
import app from './app.vue'
import './application.styl'

new Vue({
  el: '#app',
  render: h => h(app)
})
