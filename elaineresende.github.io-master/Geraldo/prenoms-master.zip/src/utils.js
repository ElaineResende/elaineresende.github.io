import * as d3 from 'd3'
import _ from 'lodash'

const colorScales = {
  a: d3.scaleOrdinal().range(['#74a9cf','#3690c0','#0570b0','#045a8d','#023858']), 
  b: d3.scaleOrdinal().range(['#fec44f','#fe9929','#ec7014','#cc4c02','#993404']),
  c: d3.scaleOrdinal().range(['#fb6a4a','#ef3b2c','#cb181d','#a50f15','#67000d']),
  d: d3.scaleOrdinal().range(['#969696']),
  e: d3.scaleOrdinal().range(['#737373'])
}

export const years = _.range(0, 80)

export function forenameColor (d) {
  return colorScales[d.sex](d.forename)
}
export const fullRange = d3.extent(years)

export const defaultDuration = 750

export function maxBirthsCount (forenames, range) {
  return _(forenames)
    .flatMap(d =>
      _(d.births)
        .filter(({ year }) => year >= range.from && year <= range.to)
        .map('births')
        .max()
    )
    .max() || 0
}

export const initialRange = { from: years[0], to: _.last(years) + 1 }
