# prenoms dataaddict

https://www.insee.fr/fr/statistiques/2540004

#### how to build:

```
npm install
npm run build
```

compiled code is located in build/

#### how to develop

```
npm run dev
```

Server now listen on localhost:8003
